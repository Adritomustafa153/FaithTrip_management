-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2025 at 12:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faithtrip_accounts`
--

-- --------------------------------------------------------

--
-- Table structure for table `companyprofile`
--

CREATE TABLE `companyprofile` (
  `CompanyID` int(11) NOT NULL,
  `CompanyName` varchar(255) DEFAULT NULL,
  `StaffName` varchar(255) DEFAULT NULL,
  `Designation` varchar(100) DEFAULT NULL,
  `StaffDateOfBirth` date DEFAULT NULL,
  `PassportNumber` varchar(50) DEFAULT NULL,
  `PassportExpiryDate` date DEFAULT NULL,
  `CompanyAddress` text DEFAULT NULL,
  `CompanyEmail` varchar(50) NOT NULL,
  `PersonAddress` text DEFAULT NULL,
  `CompanyPhoneNumber` varchar(20) DEFAULT NULL,
  `PersonPhoneNumber` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `companyprofile`
--

INSERT INTO `companyprofile` (`CompanyID`, `CompanyName`, `StaffName`, `Designation`, `StaffDateOfBirth`, `PassportNumber`, `PassportExpiryDate`, `CompanyAddress`, `CompanyEmail`, `PersonAddress`, `CompanyPhoneNumber`, `PersonPhoneNumber`) VALUES
(1, 'Paramount Textiles Limited', 'AHM Habibur Rahman', 'Director', '1985-12-10', 'A07499632', '2033-05-16', 'House #22, Road #113/A, Gulshan Circle 2, Dhaka-1212, Bangladesh.', 'chairman@faithtrip.net', 'House 113 Dhaka Road, Dhaka, Dhaka 1209\r\n', '01730735465', '01717649044'),
(2, 'Universal Textiles and Manchinery ', 'MR MAHABUB ALAM RONY (ADT)\r\n', 'Managing Director', '1984-02-02', 'A02210722', '2031-11-16', 'Flat B-5, Level #05, House #594, Road #08, Avenue #05, Mirpur DOHS, Dhaka-1216, Bangladesh', '', 'Flat B-5, Level #05, House #594, Road #08, Avenue #05, Mirpur DOHS, Dhaka-1216, Bangladesh', '01727623604', '01708520767'),
(3, 'Fashion Steps LTD', 'Mr Md Sazzad Hossain,\r\nMr Md Rabiul Islam,\r\nMr Md Rabiul Islam', 'Marketing Manager', NULL, NULL, NULL, 'Plot#16 (old – 101) Block # D, Tongi I/A,Gazipur-1712, Bangladesh', '', NULL, NULL, NULL),
(4, 'NICCA Chemical CO. LTD', 'BANIK/BISWAJIT MR, \r\nCHAKRABOTRTY/DEBASHISH MR, \r\nCHANGGEUN/PARK MR, \r\nMORISHITA/YOSHIYUKI MR,\r\nTAKEUCHI/KOTARO MR', 'Manager', NULL, NULL, NULL, 'Suvastu Suraiya Trade Center 3A (3rd Floor), 57 Kamal Ataturk Avenue, Banani, Dhaka 1213', '', NULL, '0255033391', NULL),
(5, 'ASIA JAPAN REAL ESTATE DHAKA LTD.', 'HOSSAIN/MD SUMON MR', 'Sales', '2025-03-18', NULL, '2025-03-23', '5B, House 73, Road#4, Block-C, Banani, Dhaka 1213,Bangladesh', '', '5B, House 73, Road#4, Block-C, Banani, Dhaka 1213,Bangladesh', NULL, NULL),
(6, 'Nippon Garments Industries Limited ', 'Abedin Mohammad Nazim Uddin Bhuiyan', 'Managing Director', '1985-12-10', NULL, NULL, 'Abedin Tower (Level 8), 35 Kamal Ataturk Avenue , Banani Road 17, Dhaka 1213', '', NULL, NULL, NULL),
(7, 'Vision Group', 'Quazi Mushtaque Ali Mashum', 'Executive Director Merchandising', '1978-12-09', 'A13302101', '2033-11-21', '429, Shenpara Parbata, Mirpur-10, Dhaka 1216', 'mashum@vision-bd.com', '', '01713239707', '01972005725'),
(8, 'Quality Textile Sourcing', 'Towhid Hasan', 'CEO', '0000-00-00', '', '0000-00-00', 'House#Ta-160/5, (5th Floor), Gulshan Link road, Dhaka', 'towhid@qtsbd.com', 'House#Ta-160/5, (5th Floor), Gulshan Link road, Dhaka', '01711073602', '01711073602');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companyprofile`
--
ALTER TABLE `companyprofile`
  ADD PRIMARY KEY (`CompanyID`),
  ADD UNIQUE KEY `PassportNumber` (`PassportNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companyprofile`
--
ALTER TABLE `companyprofile`
  MODIFY `CompanyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
