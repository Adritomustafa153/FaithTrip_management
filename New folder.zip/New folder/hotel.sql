-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2025 at 12:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faithtrip_accounts`
--

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE `hotel` (
  `id` int(11) NOT NULL,
  `hotelName` varchar(255) NOT NULL,
  `country` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `partyName` varchar(255) DEFAULT NULL,
  `pessengerName` varchar(255) DEFAULT NULL,
  `checkin_date` date NOT NULL,
  `checkout_date` date NOT NULL,
  `issue_date` date NOT NULL,
  `hotel_category` varchar(30) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `room_category` varchar(50) NOT NULL,
  `issued_by` varchar(255) NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `net_price` decimal(10,2) NOT NULL,
  `reference_number` varchar(50) NOT NULL,
  `profit` decimal(10,2) GENERATED ALWAYS AS (`selling_price` - `net_price`) STORED,
  `invoice_number` varchar(15) NOT NULL,
  `payment_status` enum('Paid','Not Paid','Pending','Partially Paid') NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `paid_amount` decimal(10,2) DEFAULT 0.00,
  `due_amount` decimal(10,2) GENERATED ALWAYS AS (`selling_price` - `paid_amount`) STORED,
  `bank_name` varchar(255) DEFAULT NULL,
  `deposit_date` date DEFAULT NULL,
  `clearing_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`id`, `hotelName`, `country`, `address`, `partyName`, `pessengerName`, `checkin_date`, `checkout_date`, `issue_date`, `hotel_category`, `room_type`, `room_category`, `issued_by`, `selling_price`, `net_price`, `reference_number`, `invoice_number`, `payment_status`, `payment_method`, `paid_amount`, `bank_name`, `deposit_date`, `clearing_date`) VALUES
(1, 'Bengaluru (India)\r\nHilton Garden Inn Bengaluru Embassy \r\nManyata Business Park', '', 'Embassy Manyata Business Park Hebbal, Outer Ring Road, \nNagawara, Bengaluru, 560045, India, Bengaluru, 560045, \nIndia', 'Paramount Textiles Limited', 'AHM Habibur Rahman, \r\nKamal Husain', '2025-02-17', '2025-02-20', '2025-02-16', '', '', '', 'Adrito', 106555.00, 95187.00, 'HBC1358HD2372', 'INV-3245252', 'Not Paid', NULL, 0.00, NULL, NULL, NULL),
(2, 'Taj City Centre Gurugram\r\n', '', 'Plot No.1, Sector 44, Gurugram, Haryana 122004,, Gurugram/gurgaon', 'Paramount Textiles Limited', 'Mr A H M HABIBUR RAHMAN,\r\nMr MD KAMAL HUSAIN', '2025-02-20', '2025-02-22', '2025-02-19', '', '', '', 'Adrito', 96000.00, 85050.00, 'HBC761UPO4931', 'INV-2494512', 'Pending', NULL, 0.00, NULL, NULL, NULL),
(3, 'Hilton London Metropole', 'London', '225 Edgware Road, W2 1JU London, London, W2 1JU,  United Kingdom', 'Paramount Textiles Limited', 'AHM Habibur Rahman', '2025-02-04', '2025-02-08', '2025-02-03', '', '', '', 'Adrito Mustafa', 138733.00, 119893.00, 'HBC548X6S3227', 'INV-8149826', 'Paid', 'Cheque Clearing', 138733.00, 'City Bank Ltd', '2025-02-15', '2025-02-16'),
(17, 'Radisson Collection Hotel Hyland Shanghai(  Ex. Sofitel Shanghai Hyland)', 'Bangladesh', 'ABEDIN TOWER', 'Counter Sell', 'Mr. MD HUMAYOUN KABIR, Mr. MD SALAUDDIN KHAN ', '2025-02-27', '2025-03-07', '2025-02-18', '5star', 'breakfast', 'Delux', 'Adrito Mustafa', 169520.00, 166320.00, 'HBC548X6S3228', 'INV-3737307', '', 'Cash Payment', 50000.00, 'Southeast Bank Limited', '0000-00-00', '0000-00-00');

--
-- Triggers `hotel`
--
DELIMITER $$
CREATE TRIGGER `before_insert_hotel` BEFORE INSERT ON `hotel` FOR EACH ROW BEGIN
    IF NEW.invoice_number IS NULL OR NEW.invoice_number = '' THEN
        SET NEW.invoice_number = CONCAT('INV-', FLOOR(RAND() * (9999999 - 1000 + 1) + 1000));
    END IF;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference_number` (`reference_number`),
  ADD UNIQUE KEY `invoice_number` (`invoice_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hotel`
--
ALTER TABLE `hotel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
