-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2025 at 12:45 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faithtrip_accounts`
--

-- --------------------------------------------------------

--
-- Table structure for table `sources`
--

CREATE TABLE `sources` (
  `id` int(11) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `iata_number` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sources`
--

INSERT INTO `sources` (`id`, `agency_name`, `address`, `email`, `contact_person`, `phone_number`, `iata_number`) VALUES
(1, 'Airtrip International LTD', ' SUITE5/3(4THFLOOR),CITYHEART ,67NAYAPALTAN, DHAKA', 'airtrip@timesgroupbd.com', 'Zahidul Islam Saikat', '+880 1677-139574', '42300495'),
(2, 'Fly Away Travels', 'HOUSE67C-1,ROAD-13B,BLOCK-E BANANI C/A DHAKA', 'info@flyaway.com.bd', 'Monsur Ahmed Saiful', '+880 1713-410633', NULL),
(3, 'IATA', 'Abedin Tower(Level 5),Road 17, 35 Kamal Ataturk Avenue, Banani, Dhaka 1213', 'director@faithtrip.net', 'AHM Habibur Rahman', '+8801717649044', '42344282'),
(4, 'Flight Expert', 'Motijheel City Center', 'agents@flightexpertagent.com', 'Rocky', '+880 1325-085147', ''),
(5, 'Indigo ', '10th Floor, Autograph Building, 67-68, Kemal Ataturk Avenue, Banani Model Town, Dhaka-1212', 'munaf.sheikh@rasl-bd.com', 'Munaf Shikh', '+880 1313-494777', ''),
(6, 'AMY BD', 'Moqbul Cube Inventure, 11th Floor, House-07, Block-D, Road-17, Banani, Dhaka-1213, Gulshan, Dhaka 1213', 'agents@amybd.com', 'Sajib', '01730358942', ''),
(7, 'T360 Tours and Travels', 'House 74 (3rd floor), Block H, Road 7, Banani, Dhaka 1213', '', 'Mr Fahim Shariar (CEO)', '+8801715950416', '42343862');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sources`
--
ALTER TABLE `sources`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sources`
--
ALTER TABLE `sources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
