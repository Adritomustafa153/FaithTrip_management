-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2025 at 12:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faithtrip_accounts`
--

-- --------------------------------------------------------

--
-- Table structure for table `reissue_sales`
--

CREATE TABLE `reissue_sales` (
  `id` int(11) NOT NULL,
  `section` varchar(50) DEFAULT 'counter sell',
  `PartyName` varchar(100) DEFAULT 'counter sell',
  `PassengerName` varchar(100) NOT NULL,
  `airlines` varchar(100) NOT NULL,
  `TicketRoute` varchar(100) NOT NULL,
  `TicketNumber` varchar(50) NOT NULL,
  `Class` varchar(50) DEFAULT NULL,
  `IssueDate` date DEFAULT NULL,
  `FlightDate` date DEFAULT NULL,
  `ReturnDate` date DEFAULT NULL,
  `PNR` varchar(50) NOT NULL,
  `BillAmount` decimal(10,2) NOT NULL,
  `NetPayment` decimal(10,2) NOT NULL,
  `Profit` decimal(10,2) DEFAULT NULL,
  `PaymentStatus` varchar(50) DEFAULT NULL,
  `PaidAmount` decimal(10,2) DEFAULT NULL,
  `DueAmount` decimal(10,2) DEFAULT NULL,
  `PaymentMethod` varchar(50) DEFAULT NULL,
  `BankName` varchar(100) DEFAULT NULL,
  `BranchName` varchar(100) DEFAULT NULL,
  `AccountNumber` varchar(50) DEFAULT NULL,
  `ReceivedDate` date DEFAULT NULL,
  `DepositDate` date DEFAULT NULL,
  `ClearingDate` date DEFAULT NULL,
  `SalesPersonName` varchar(100) DEFAULT NULL,
  `invoice_number` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reissue_sales`
--
ALTER TABLE `reissue_sales`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reissue_sales`
--
ALTER TABLE `reissue_sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
