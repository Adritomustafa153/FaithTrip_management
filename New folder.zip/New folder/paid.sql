-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2025 at 12:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faithtrip_accounts`
--

-- --------------------------------------------------------

--
-- Table structure for table `paid`
--

CREATE TABLE `paid` (
  `id` int(11) NOT NULL,
  `source` varchar(100) DEFAULT NULL,
  `payment_date` date NOT NULL,
  `invoice_no` varchar(100) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `receipt` varchar(255) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paid`
--

INSERT INTO `paid` (`id`, `source`, `payment_date`, `invoice_no`, `transaction_id`, `payment_method`, `receipt`, `amount`, `remarks`) VALUES
(16, 'Fly Away Travels', '2025-06-03', '', '', 'Cheque', '', 50000.00, 'Cash Cheque given to Flyaway office'),
(20, 'IATA', '2025-06-15', '', '', 'Clearing Cheque', '', 650000.00, ''),
(21, 'Fly Away Travels', '2025-06-29', '5106', '', 'Cash', 'receipt_686615ecf1159.jpg', 60500.00, 'Cash paid at the office for previous 10,339 + 50,161 for July 15 forth night'),
(22, 'Airtrip International LTD', '2025-07-13', '77634', '', 'Cash', 'receipt_687396335a46e.jpg', 200000.00, '2 lacs cash deposit at city bank banani branch for July 15 fortnight. Total bill 520,979. Remaining 320,979 BDT'),
(23, 'IATA', '2025-07-13', '130208', '2567238', 'Clearing Cheque', 'receipt_687398028223f.jpg', 884009.00, 'Paid at SCB'),
(24, 'Fly Away Travels', '2025-07-13', '5111', '', 'Cheque', 'receipt_68739964dc316.jpg', 272696.00, 'Cheque given at office'),
(25, 'Fly Away Travels', '2025-07-13', '5110', '', 'Cheque', 'receipt_68739afe99c52.jpg', 280000.00, 'Cheque deposit at office'),
(26, 'Airtrip International LTD', '2025-07-14', '', '', 'Bank Transfer', 'receipt_68776d2e9f778.jpg', 340000.00, 'Paid to Premier bank. Cash Loan 3 lacs from MD'),
(27, 'IATA', '2025-07-28', '116932', '', 'Clearing Cheque', 'receipt_688758d965037.jpg', 234740.00, 'Paid at Standard chaterd bank banani'),
(28, 'Fly Away Travels', '2025-07-28', '5114', '', 'Cheque', 'receipt_6887591480ba8.jpg', 1069445.00, 'City Bank cheque paid at fly away office. Cheque No. : 2567243'),
(29, 'Airtrip International LTD', '2025-07-28', '', '', 'Clearing Cheque', 'receipt_688759815e744.jpg', 100000.00, 'IBBL Clearing cheque given to Premier Bank Banani Branch. Chq No. : 0871733'),
(30, 'Airtrip International LTD', '2025-07-28', '', '', 'Clearing Cheque', 'receipt_6887599d98922.jpg', 110000.00, 'IBBL Clearing cheque given to Premier Bank Banani Branch. Chq No. : 8656399'),
(31, 'Airtrip International LTD', '2025-07-28', '76782', '', 'Cash', 'receipt_68875a6788cb5.jpg', 147140.00, 'Cash Deposit At City Bank Banani');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `paid`
--
ALTER TABLE `paid`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `paid`
--
ALTER TABLE `paid`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
