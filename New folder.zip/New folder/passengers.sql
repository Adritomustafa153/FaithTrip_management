-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2025 at 12:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faithtrip_accounts`
--

-- --------------------------------------------------------

--
-- Table structure for table `passengers`
--

CREATE TABLE `passengers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `Address` varchar(300) DEFAULT NULL,
  `PassengerEmail` varchar(100) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `passport_number` varchar(50) DEFAULT NULL,
  `passport_expiry` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `passengers`
--

INSERT INTO `passengers` (`id`, `name`, `Address`, `PassengerEmail`, `date_of_birth`, `passport_number`, `passport_expiry`) VALUES
(3, 'Adrito Mustafa', NULL, 'adrito642@gmail.com', '2025-05-12', 'A897564', '2025-08-06'),
(7, 'CHOWDHURY/SUMANAH SAFI MS', NULL, 'director@faithtrip.net', '2004-12-18', 'A01743887', '2026-08-01'),
(8, 'Mahabub Alam Rony', 'Flat B-5, Level #05, House #594, Road #08, Avenue #05, Mirpur DOHS, Dhaka-1216, Bangladesh', '', '1984-02-02', 'A02210722', '2031-11-16'),
(9, 'SARKER/ASISH MR', NULL, 'marketing1@faithtrip.net', '1979-06-01', 'A12308174', '2033-11-07'),
(10, 'Mr JONY BASHAK ', NULL, 'director@faithtrip.net', '1987-08-01', 'A11176589', '2033-07-04'),
(11, 'AHAMMED/MOHAMMAD NUR MR', NULL, 'director@faithtrip.net', '1993-05-18', 'A18401115', '2035-04-13'),
(12, 'Mr. Thowsif ahmed Chowdhury', NULL, 'syedmukul@gmail.com', '2025-08-19', 'A16888223', '2033-11-03'),
(13, 'Ms. Tasnim Chowdhury', NULL, 'syedmukul@gmail.com', '2011-06-08', 'A13250749', '2028-11-14'),
(14, 'Lucky begum Chowdhury', NULL, 'syedmukul@gmail.com', '1979-10-10', 'A16888224', '2034-11-03'),
(15, ' Ishfaq ahmed Chowdhury', NULL, 'syedmukul@gmail.com', '2000-08-11', 'A16888223', '2034-11-03'),
(16, ' Wakil ahmed Chowdhury', NULL, 'syedmukul@gmail.com', '1973-07-09', 'A17441993', '2034-12-25'),
(17, 'Nasima khanom Chowdhury', NULL, 'syedmukul@gmail.com', '1976-03-15', 'A17108956', '2034-12-01'),
(18, 'PALAS CHANDRA DAS', NULL, 'marketing1@faithtrip.net', '1983-01-15', 'A17107532', '2034-12-01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `passengers`
--
ALTER TABLE `passengers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `passengers`
--
ALTER TABLE `passengers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
