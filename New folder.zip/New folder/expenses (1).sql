-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2025 at 12:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faithtrip_accounts`
--

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `expense_date` date NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `expense_date`, `category`, `description`, `amount`, `created_at`) VALUES
(1, '2025-05-21', 'Purchase', 'Ring File Purchase for keeping air tickets due and received', 280.00, '2025-05-22 09:51:27'),
(2, '2025-05-21', 'Purchase', 'Mouse Purchase for adrito laptop', 850.00, '2025-05-22 20:58:49'),
(3, '2025-06-01', 'Service Expense', 'Server rent payment to Getup LTD from February 2025 to May 2025', 21000.00, '2025-06-01 06:24:48'),
(4, '2025-06-02', 'Convince Allowence', 'Convince Allowence for adrito for collection pinaki group cheque', 430.00, '2025-06-02 18:32:17'),
(5, '2025-06-04', 'Salary', 'Salary of Dipon', 40000.00, '2025-06-04 05:46:02'),
(6, '2025-06-04', 'Salary', 'Salary of Adrito', 25000.00, '2025-06-04 05:46:19'),
(7, '2025-06-04', 'Salary', 'Salary of Ripon', 20000.00, '2025-06-04 05:46:37'),
(8, '2025-06-04', 'Bonus', 'Bonus of Dipon', 16000.00, '2025-06-04 05:46:53'),
(9, '2025-06-04', 'Bonus', 'Bonus of Adrito', 10000.00, '2025-06-04 05:47:09'),
(10, '2025-06-04', 'Bonus', 'Bonus of Ripon', 8000.00, '2025-06-04 05:47:23'),
(11, '2025-06-04', 'House Rent', 'Payment for House rent, Beverage bill, Meeting room rent of ShareOn', 34920.00, '2025-06-04 05:48:08'),
(12, '2025-06-03', 'Convince Allowence', 'Convince allowence of adrito from Khilgaon to BGMEA', 355.00, '2025-06-04 06:09:40'),
(13, '2025-06-04', 'Miscellaneous', 'Eid salami to all stuffs of ShareOn & Lift operators', 4000.00, '2025-06-04 10:55:57'),
(14, '2025-06-16', 'Purchase', 'Snacks Purchase for AirAstra guest', 530.00, '2025-06-16 09:04:40'),
(15, '2025-06-17', 'Purchase', 'Tissue Box', 100.00, '2025-06-17 05:59:36'),
(16, '2025-06-17', 'Purchase', 'HP 680 Printer Cartige', 1200.00, '2025-06-17 05:59:58'),
(17, '2025-06-17', 'Purchase', 'Godrej aer Air freshner 300ml', 300.00, '2025-06-17 06:00:48'),
(18, '2025-06-16', 'Convince Allowence', 'Convienc Allowence for Adrito ', 520.00, '2025-06-17 06:08:29'),
(19, '2025-05-31', 'Purchase', 'Banner printing for B2B agents', 8000.00, '2025-06-18 06:54:50'),
(20, '2025-06-18', 'Service Expense', 'ShareOn vat payment over house rent', 4530.00, '2025-06-18 12:13:43'),
(21, '2025-06-22', 'VAT & TAX', 'Paid to Aminul Islam for AIT Payment', 1505.00, '2025-06-22 06:50:15'),
(22, '2025-06-22', 'Mobile Bill Allowence', 'Mobile Bill paid for Adrito , Ripon & Dipon', 3000.00, '2025-06-22 06:51:45'),
(23, '2025-06-30', 'Purchase', 'Paper purchase 2 rim, Basket, Staplare, PIN, Ball Pen, Gel Pen Purchase', 1290.00, '2025-06-30 05:07:27'),
(24, '2025-07-03', 'Administrative Cost', 'Paid to Aminul Islam for trade license renew fee of 2025-2026', 13236.00, '2025-07-03 05:23:46'),
(25, '2025-07-03', 'Purchase', 'Purchase paper tray, Laminating IATA, TIN, BIN, Civil Avation, Tradelicense , Purchase GUM Tep, Purchase double side tep', 440.00, '2025-07-03 11:20:10'),
(26, '2025-07-13', 'Salary', 'Salary of Dipon', 40000.00, '2025-07-17 11:32:31'),
(27, '2025-07-13', 'Salary', 'Salary of Adrito', 25000.00, '2025-07-17 11:48:49'),
(28, '2025-07-07', 'House Rent', 'House rent of july', 30000.00, '2025-07-17 11:51:10'),
(29, '2025-07-07', 'Office Expense', 'Beverage bill to shareon', 1350.00, '2025-07-17 11:51:51'),
(30, '2025-07-23', 'Purchase', 'Ink Cartige HP680 ', 2400.00, '2025-07-23 10:29:36'),
(31, '2025-07-20', 'Salary', 'Salary of Ripon', 20000.00, '2025-07-23 10:30:18'),
(32, '2025-07-20', 'Mobile Bill Allowence', 'Mobile bill for Ripon', 1000.00, '2025-07-23 10:30:48'),
(33, '2025-07-27', 'Software Service Expence', 'Faithtrip portal server payment for Getup ltd', 15750.00, '2025-07-27 08:49:00'),
(34, '2025-08-02', 'Printing Stationary', 'Visiting card printing For Aminul Islam', 1000.00, '2025-08-02 12:16:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
