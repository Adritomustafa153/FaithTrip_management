-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2025 at 12:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faithtrip_accounts`
--

-- --------------------------------------------------------

--
-- Table structure for table `sales_person`
--

CREATE TABLE `sales_person` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nid` varchar(50) NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `joining_date` date NOT NULL,
  `date_of_birth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_person`
--

INSERT INTO `sales_person` (`id`, `name`, `address`, `phone`, `email`, `nid`, `employee_id`, `joining_date`, `date_of_birth`) VALUES
(1, 'Adrito Mustafa', '178/B Rajonigondha Vallly, Khilgaon Chowdhurypara, Matirmoshjheed jheelpar, Dhaka 1219', '01950463204', 'adrito642@gmail.com', '7355279675', '', '2024-02-03', '1999-10-30'),
(5, 'Anik Basak', 'Police Plaza Dhaka', '+880 1896-459484', 'marketing1@faithtrip.net', '3825123895', '2', '2024-02-07', '1996-10-12'),
(6, 'Mir Sultanul Alam (Dipon)', 'Jatrabari', '01715750300', 'director@faithtrip.net', '3269893164', '202402001', '2024-02-03', '1974-10-23'),
(7, 'AL Hassan Mahmud Ripon', 'Bhuiyan Bari, Dhuliyamuri, kolakhal, barura comilla', '', 'inf0@faithtrip.net', '4638641326', '202501004', '2025-01-05', '0000-00-00'),
(10, 'Abdul Kabir Farhan', '429, Shenpara Parbata, Mirpur-10, Dhaka 1216', '+8801896459583', 'faithtrip.net@gmail.com', '7354403789', '202404001', '2024-04-06', '1998-10-13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sales_person`
--
ALTER TABLE `sales_person`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `nid` (`nid`),
  ADD UNIQUE KEY `employee_id` (`employee_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sales_person`
--
ALTER TABLE `sales_person`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
